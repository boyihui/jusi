ALTER TABLE `stock_details` MODIFY COLUMN `industry` text;--> statement-breakpoint
ALTER TABLE `stock_details` MODIFY COLUMN `hotConcept` text;--> statement-breakpoint
ALTER TABLE `stock_details` ADD `secondaryIndustry` text;